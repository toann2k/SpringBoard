const todos = [];  


document.addEventListener("DOMContentLoaded", function() 
{
  console.log(todos.length);
 
  let todoForm = document.getElementById("todoForm");
  let todoList = document.getElementById("todoList");

  todoForm.addEventListener("submit", function(event) {
    event.preventDefault()
  let removeButton = document.createElement("button");
  removeButton.innerText = "Remove";

  let newtask = document.createElement("li");
  newtask.innerText = document.getElementById("task").value;
 
  todoList.appendChild(newtask);
  newtask.appendChild(removeButton);
  
  localStorage.setItem("todos", newtask.innerText);

 

  todoForm.reset();

  });

  todoList.addEventListener("click", function(event) 
  {
     const targetTagToLowerCase = event.target.tagName.toLowerCase();
    if (targetTagToLowerCase === "button") {
      event.target.parentNode.remove();
    }
  });

});


